const Mustache = require('mustache')
const csv = require('csv-parser')
const results = []
var fs = require('fs');	

// First I want to read the file
var template = fs.readFileSync("template/Sampone.html","utf-8");

processFile()
const getExelval1=new Promise((resolve,reject)=>{
	fs.createReadStream("in.csv")
	.pipe(csv())
	.on('data', (data) => results.push(data));
	  resolve(results)
});
	
function processFile() {
	Mustache.parse(template);   // optional, speeds up future uses
	async function check(){
        const excelData=await getExelval1;
        
        var ts =  excelData[0]['title']
        var des = excelData[0]['description']
        var img = excelData[0]['image']
        var lg = excelData[0]['logo']
		var rendered = Mustache.render(template, {
            title : ts, 
            description : des,
            image:img,logo:lg});
		console.log(rendered)
		fs.appendFile('mynewfile21.html', rendered, function (err) {
			if (err) throw err;
			console.log('Saved!');
		})
	}setTimeout(check,1000)
}
